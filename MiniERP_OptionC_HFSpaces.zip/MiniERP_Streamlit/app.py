# -*- coding: utf-8 -*-
from __future__ import annotations

import os, io, datetime
import pandas as pd
import streamlit as st

import minierp_db as db

st.set_page_config(page_title="MiniERP (Local)", layout="wide")

# ---------------------------
# Helpers
# ---------------------------
def money_fmt(x):
    try:
        return f"{float(x):,.0f}".replace(",", ".")
    except Exception:
        return str(x)

def init_session():
    for k, v in {
        "logged": False,
        "user_id": None,
        "role": None,
        "company_id": None,
        "company_label": None,
        "purchase_lines": [],
    }.items():
        st.session_state.setdefault(k, v)

def logout():
    for k in list(st.session_state.keys()):
        if k in ("logged","user_id","role","company_id","company_label","purchase_lines"):
            st.session_state[k] = None if k not in ("logged","purchase_lines") else ([] if k=="purchase_lines" else False)
    st.rerun()

def company_options():
    d = db.user_companies(int(st.session_state["user_id"]), str(st.session_state["role"]))
    opts = []
    for _, r in d.iterrows():
        opts.append((int(r["id"]), db.company_label(r)))
    return d, opts

def get_recent_cost_centers(company_id: int) -> list[str]:
    ccs = set()
    for q in [
        "SELECT DISTINCT COALESCE(cost_center,'') cc FROM purchases WHERE company_id=? AND cost_center IS NOT NULL AND cost_center<>'' LIMIT 200",
        "SELECT DISTINCT COALESCE(cost_center,'') cc FROM other_expenses WHERE company_id=? AND cost_center IS NOT NULL AND cost_center<>'' LIMIT 200",
        "SELECT DISTINCT COALESCE(cost_center,'') cc FROM stock_moves WHERE company_id=? AND cost_center IS NOT NULL AND cost_center<>'' LIMIT 200",
    ]:
        d = db.read_df(q, (company_id,))
        for cc in d["cc"].tolist() if len(d) else []:
            ccs.add(str(cc))
    return sorted([x for x in ccs if x.strip()])

def cc_picker(company_id: int, key_prefix: str, label: str="Centro de costo"):
    recent = get_recent_cost_centers(company_id)
    choice = st.selectbox(label, options=["(Nuevo / Manual)"] + recent, key=f"{key_prefix}_cc_choice")
    if choice == "(Nuevo / Manual)":
        return st.text_input("Escribe CC (opcional)", value="", key=f"{key_prefix}_cc_manual").strip()
    return choice

def df_download_button(df_: pd.DataFrame, filename: str, label: str="Descargar CSV"):
    csv_bytes = df_.to_csv(index=False).encode("utf-8")
    st.download_button(label, data=csv_bytes, file_name=filename, mime="text/csv")

# ---------------------------
# App
# ---------------------------
db.ensure_seed()
init_session()

st.title("MiniERP (Local) — Streamlit + SQLite")

if not st.session_state["logged"]:
    st.subheader("Login")
    with st.form("login_form", clear_on_submit=False):
        u = st.text_input("Usuario", value="")
        p = st.text_input("Clave", value="", type="password")
        submitted = st.form_submit_button("Entrar")
    if submitted:
        ok, msg, user_id, role = db.login(u, p)
        if not ok:
            st.error(msg)
        else:
            st.session_state["logged"] = True
            st.session_state["user_id"] = user_id
            st.session_state["role"] = role
            # choose first company
            d, opts = company_options()
            if not opts:
                st.error("No tienes empresas asignadas. (Admin debe asignarte al menos una).")
                st.session_state["logged"] = False
            else:
                st.session_state["company_id"] = opts[0][0]
                st.session_state["company_label"] = opts[0][1]
                st.rerun()
    st.stop()

# Sidebar
with st.sidebar:
    st.markdown("### Sesión")
    st.write(f"**Usuario:** {st.session_state['user_id']}  \n**Rol:** {st.session_state['role']}")
    if st.button("Cerrar sesión"):
        logout()

    st.markdown("---")
    st.markdown("### Empresa")
    d, opts = company_options()
    labels = [lab for _, lab in opts]
    current_label = st.session_state.get("company_label")
    if current_label not in labels and labels:
        current_label = labels[0]
    chosen_label = st.selectbox("Selecciona empresa", options=labels, index=(labels.index(current_label) if current_label in labels else 0))
    chosen_id = opts[labels.index(chosen_label)][0] if labels else None
    if chosen_id and chosen_id != st.session_state.get("company_id"):
        st.session_state["company_id"] = chosen_id
        st.session_state["company_label"] = chosen_label
        st.session_state["purchase_lines"] = []
        st.rerun()

    st.markdown("---")
    pages = ["📊 Dashboard", "🧾 Compras", "📦 Movimientos", "🧾 Gastos", "📑 Reportes"]
    if st.session_state["role"] == "admin":
        pages.append("🔐 Admin")
    page = st.radio("Menú", pages)

company_id = int(st.session_state["company_id"])
company = db.get_company(company_id)

st.caption(f"Empresa: **{company['rut']} — {company['name']} ({company['rubro']})**")

# ---------------------------
# Dashboard (incluye maestros)
# ---------------------------
if page == "📊 Dashboard":
    col1, col2 = st.columns([2, 1])

    with col1:
        st.subheader("Stock actual")
        stock = db.stock_now(company_id)
        st.dataframe(stock, use_container_width=True, hide_index=True)

    with col2:
        st.subheader("Alertas")
        if len(stock):
            low = stock[(stock["stock"].astype(float) < stock["min_stock"].astype(float, errors="ignore").fillna(0))]
            if len(low):
                st.warning("Productos bajo stock mínimo:")
                st.dataframe(low[["name","stock","min_stock","unit"]], use_container_width=True, hide_index=True)
            else:
                st.success("Sin alertas de stock mínimo.")
        else:
            st.info("No hay productos activos.")

    st.markdown("---")
    st.subheader("Maestros (Familias / Productos / Proveedores)")
    tab_fam, tab_prod, tab_sup = st.tabs(["Familias", "Productos", "Proveedores"])

    with tab_fam:
        fam = db.list_families(company_id)
        st.dataframe(fam, use_container_width=True, hide_index=True)

        st.markdown("#### Crear / editar")
        fam_id = st.selectbox("Selecciona familia para editar (opcional)", options=[0] + fam["id"].tolist() if len(fam) else [0])
        fam_name_default = ""
        if fam_id and len(fam):
            row = fam[fam["id"] == fam_id]
            if len(row):
                fam_name_default = str(row.iloc[0]["name"])
        fam_name = st.text_input("Nombre familia", value=fam_name_default)
        c1, c2, c3 = st.columns([1,1,2])
        with c1:
            if st.button("Guardar familia"):
                msg = db.upsert_family(company_id, fam_name, fam_id if fam_id else None)
                st.info(msg)
                st.rerun()
        with c2:
            if fam_id and st.button("Borrar familia"):
                st.warning(db.delete_family(company_id, fam_id))
                st.rerun()
        with c3:
            st.caption("Si borras una familia, los productos quedan sin familia (no se pierde el historial).")

    with tab_prod:
        prod = db.list_products(company_id, active_only=False)
        st.dataframe(prod, use_container_width=True, hide_index=True)

        st.markdown("#### Crear / editar")
        prod_ids = [0] + (prod["id"].tolist() if len(prod) else [])
        sel_pid = st.selectbox("Selecciona producto para editar (opcional)", options=prod_ids)
        sel_row = prod[prod["id"] == sel_pid] if sel_pid and len(prod) else None

        fam = db.list_families(company_id)
        fam_opts = [("","(Sin familia)")] + [(str(r["id"]), str(r["name"])) for _, r in fam.iterrows()] if len(fam) else [("","(Sin familia)")]
        fam_labels = [x[1] for x in fam_opts]

        sku = st.text_input("SKU (opcional)", value=(str(sel_row.iloc[0]["sku"]) if sel_row is not None and len(sel_row) else ""))
        name = st.text_input("Nombre producto", value=(str(sel_row.iloc[0]["name"]) if sel_row is not None and len(sel_row) else ""))
        unit = st.text_input("Unidad (UN, KG, LT…)", value=(str(sel_row.iloc[0]["unit"]) if sel_row is not None and len(sel_row) else "UN"))
        min_stock = st.number_input("Stock mínimo", value=(float(sel_row.iloc[0]["min_stock"]) if sel_row is not None and len(sel_row) else 0.0))
        active = st.checkbox("Activo", value=(bool(int(sel_row.iloc[0]["active"])) if sel_row is not None and len(sel_row) else True))
        fam_label_default = "(Sin familia)"
        if sel_row is not None and len(sel_row):
            fam_label_default = str(sel_row.iloc[0]["family"] or "(Sin familia)")
        fam_pick = st.selectbox("Familia", options=fam_labels, index=(fam_labels.index(fam_label_default) if fam_label_default in fam_labels else 0))
        fam_id = ""
        for _id, lab in fam_opts:
            if lab == fam_pick:
                fam_id = _id
                break

        c1, c2, c3 = st.columns([1,1,2])
        with c1:
            if st.button("Guardar producto"):
                msg = db.upsert_product(company_id, sku, name, int(fam_id) if fam_id else None, unit, min_stock, active, sel_pid if sel_pid else None)
                st.info(msg)
                st.rerun()
        with c2:
            if sel_pid and st.button("Borrar producto"):
                st.warning(db.delete_product(company_id, sel_pid))
                st.rerun()
        with c3:
            st.caption("Si no se puede borrar (histórico), desactívalo desmarcando 'Activo'.")

    with tab_sup:
        sup = db.list_suppliers(company_id)
        st.dataframe(sup, use_container_width=True, hide_index=True)

        st.markdown("#### Crear / editar")
        sup_ids = [0] + (sup["id"].tolist() if len(sup) else [])
        sel_sid = st.selectbox("Selecciona proveedor para editar (opcional)", options=sup_ids)
        sel_row = sup[sup["id"] == sel_sid] if sel_sid and len(sup) else None

        s_name = st.text_input("Nombre proveedor", value=(str(sel_row.iloc[0]["name"]) if sel_row is not None and len(sel_row) else ""))
        s_rut = st.text_input("RUT (opcional)", value=(str(sel_row.iloc[0]["rut"]) if sel_row is not None and len(sel_row) else ""))
        s_phone = st.text_input("Teléfono (opcional)", value=(str(sel_row.iloc[0]["phone"]) if sel_row is not None and len(sel_row) else ""))
        s_email = st.text_input("Email (opcional)", value=(str(sel_row.iloc[0]["email"]) if sel_row is not None and len(sel_row) else ""))
        s_active = st.checkbox("Activo (proveedor)", value=(bool(int(sel_row.iloc[0]["active"])) if sel_row is not None and len(sel_row) else True))

        c1, c2 = st.columns([1,3])
        with c1:
            if st.button("Guardar proveedor"):
                st.info(db.upsert_supplier(company_id, s_name, s_rut, s_phone, s_email, s_active, sel_sid if sel_sid else None))
                st.rerun()
        with c2:
            if sel_sid and st.button("Borrar proveedor"):
                st.warning(db.delete_supplier(company_id, sel_sid))
                st.rerun()

# ---------------------------
# Compras
# ---------------------------
elif page == "🧾 Compras":
    if not db.require(str(st.session_state["role"]), {"admin","compras"}):
        st.error("No tienes permisos para registrar compras (solo admin/compras).")
        st.stop()

    st.subheader("Registrar Compra (Factura proveedor)")

    prod = db.list_products(company_id, active_only=True)
    suppliers = db.list_suppliers(company_id)
    prod_labels = [f"{r['name']} [{r['sku']}]" if str(r["sku"]).strip() else str(r["name"]) for _, r in prod.iterrows()] if len(prod) else []
    sup_labels = suppliers["name"].tolist() if len(suppliers) else []

    colA, colB, colC = st.columns([1,1,1])
    with colA:
        date = st.date_input("Fecha emisión", value=datetime.date.today())
    with colB:
        due = st.text_input("Vencimiento (opcional, YYYY-MM-DD)", value="")
    with colC:
        supplier_name = st.selectbox("Proveedor", options=["(Sin proveedor)"] + sup_labels)

    doc_no = st.text_input("N° Factura/Doc (opcional)", value="")
    notes = st.text_input("Notas (opcional)", value="")
    cost_center = cc_picker(company_id, "purchase")

    st.markdown("### Líneas")
    with st.expander("Agregar línea", expanded=True):
        if not prod_labels:
            st.info("Primero crea productos en Dashboard → Productos.")
        else:
            c1, c2, c3, c4, c5 = st.columns([3,1,1,1,1])
            with c1:
                p_label = st.selectbox("Producto", options=prod_labels)
            with c2:
                qty = st.number_input("Cantidad", value=1.0, min_value=0.0)
            with c3:
                unit_cost = st.number_input("Costo unit NETO", value=0.0, min_value=0.0)
            with c4:
                vat = st.number_input("IVA", value=float(db.DEFAULT_VAT), min_value=0.0, max_value=1.0, step=0.01)
            with c5:
                if st.button("Agregar"):
                    pid = int(prod.iloc[prod_labels.index(p_label)]["id"])
                    st.session_state["purchase_lines"].append({
                        "product_id": pid,
                        "product": p_label,
                        "qty": float(qty),
                        "unit_cost_net": float(unit_cost),
                        "vat_rate": float(vat),
                    })
                    st.success("Línea agregada.")
    if st.session_state["purchase_lines"]:
        lines_df = pd.DataFrame(st.session_state["purchase_lines"])
        st.dataframe(lines_df, use_container_width=True, hide_index=True)
        c1, c2 = st.columns([1,4])
        with c1:
            if st.button("Limpiar líneas"):
                st.session_state["purchase_lines"] = []
                st.rerun()
        with c2:
            net = float((lines_df["qty"]*lines_df["unit_cost_net"]).sum())
            vat_amt = float((lines_df["qty"]*lines_df["unit_cost_net"]*lines_df["vat_rate"]).sum())
            gross = net + vat_amt
            st.info(f"Totales: Neto **{money_fmt(net)}** | IVA **{money_fmt(vat_amt)}** | Total **{money_fmt(gross)}**")
    else:
        st.caption("Aún no agregas líneas.")

    if st.button("💾 Guardar compra", type="primary"):
        if not st.session_state["purchase_lines"]:
            st.error("Agrega al menos 1 línea.")
        else:
            supplier_id = None
            if supplier_name != "(Sin proveedor)" and supplier_name in sup_labels:
                supplier_id = int(suppliers.iloc[sup_labels.index(supplier_name)]["id"])
            msg = db.create_purchase(
                company_id=company_id,
                date=date.isoformat(),
                due_date=due,
                supplier_id=supplier_id,
                doc_no=doc_no,
                cost_center=cost_center,
                notes=notes,
                lines=[{
                    "product_id": ln["product_id"],
                    "qty": ln["qty"],
                    "unit_cost_net": ln["unit_cost_net"],
                    "vat_rate": ln["vat_rate"],
                } for ln in st.session_state["purchase_lines"]],
            )
            st.success(msg)
            st.session_state["purchase_lines"] = []
            st.rerun()

    st.markdown("---")
    st.subheader("Compras recientes")
    days = st.slider("Rango (días)", min_value=7, max_value=365, value=90)
    dfrom = (datetime.date.today() - datetime.timedelta(days=int(days))).isoformat()
    dto = datetime.date.today().isoformat()
    purchases = db.list_purchases(company_id, dfrom, dto)
    st.dataframe(purchases, use_container_width=True, hide_index=True)
    if len(purchases):
        df_download_button(purchases, "compras.csv", "Descargar compras (CSV)")

# ---------------------------
# Movimientos
# ---------------------------
elif page == "📦 Movimientos":
    st.subheader("Movimientos de Stock")
    prod = db.list_products(company_id, active_only=True)
    prod_labels = [f"{r['name']} [{r['sku']}]" if str(r["sku"]).strip() else str(r["name"]) for _, r in prod.iterrows()] if len(prod) else []

    tab_reg, tab_hist = st.tabs(["Registrar salida/ajuste", "Historial"])

    with tab_reg:
        if not db.require(str(st.session_state["role"]), {"admin","bodega","compras"}):
            st.error("No tienes permisos para registrar movimientos (admin/bodega/compras).")
        else:
            if not prod_labels:
                st.info("Primero crea productos en Dashboard → Productos.")
            else:
                c1, c2, c3 = st.columns([2,1,1])
                with c1:
                    prod_pick = st.selectbox("Producto", options=prod_labels)
                with c2:
                    mtype = st.selectbox("Tipo", options=["OUT (Salida)","ADJ (Ajuste +/-)"])
                with c3:
                    mdate = st.date_input("Fecha", value=datetime.date.today(), key="move_date")

                qty = st.number_input("Cantidad", value=1.0, step=1.0)
                if "ADJ" in mtype:
                    st.caption("En ajuste puedes usar negativo (ej: -2) o positivo (ej: 5).")
                cost_center = cc_picker(company_id, "move")
                ref = st.text_input("Referencia (opcional)", value="")
                notes = st.text_input("Notas (opcional)", value="")

                if st.button("Guardar movimiento", type="primary"):
                    pid = int(prod.iloc[prod_labels.index(prod_pick)]["id"])
                    if "OUT" in mtype:
                        if qty <= 0:
                            st.error("Cantidad debe ser > 0.")
                        else:
                            st.success(db.create_out_move(company_id, mdate.isoformat(), pid, float(qty), cost_center, ref, notes))
                            st.rerun()
                    else:
                        # ADJ permite negativo/positivo
                        if qty == 0:
                            st.error("Cantidad no puede ser 0.")
                        else:
                            st.success(db.create_stock_move(company_id, mdate.isoformat(), "ADJ", pid, float(qty), None, cost_center, ref, notes))
                            st.rerun()

    with tab_hist:
        days = st.slider("Rango historial (días)", min_value=7, max_value=365, value=120, key="moves_days")
        dfrom = (datetime.date.today() - datetime.timedelta(days=int(days))).isoformat()
        dto = datetime.date.today().isoformat()
        moves = db.list_stock_moves(company_id, dfrom, dto)
        st.dataframe(moves, use_container_width=True, hide_index=True)
        if len(moves):
            df_download_button(moves, "movimientos_stock.csv", "Descargar movimientos (CSV)")

# ---------------------------
# Gastos
# ---------------------------
elif page == "🧾 Gastos":
    if not db.require(str(st.session_state["role"]), {"admin","compras","gerente"}):
        st.error("No tienes permisos para registrar gastos (admin/compras/gerente).")
        st.stop()

    st.subheader("Registrar gasto (no-factura)")
    c1, c2, c3 = st.columns([1,2,1])
    with c1:
        d = st.date_input("Fecha", value=datetime.date.today(), key="exp_date")
    with c2:
        cat = st.text_input("Categoría", value="")
    with c3:
        amount = st.number_input("Monto NETO", value=0.0, min_value=0.0)

    vat = st.number_input("IVA (ej: 0.19 o 0)", value=0.0, min_value=0.0, max_value=1.0, step=0.01)
    desc = st.text_input("Descripción (opcional)", value="")
    method = st.selectbox("Método", options=["transferencia","efectivo","cheque","tarjeta","otro"])
    ref = st.text_input("Referencia (opcional)", value="")
    cost_center = cc_picker(company_id, "exp")
    notes = st.text_input("Notas (opcional)", value="")

    if st.button("Guardar gasto", type="primary"):
        st.success(db.add_other_expense(company_id, d.isoformat(), cat, desc, amount, vat, method, ref, cost_center, notes))
        st.rerun()

    st.markdown("---")
    st.subheader("Gastos recientes")
    days = st.slider("Rango (días)", min_value=7, max_value=365, value=90, key="exp_days")
    dfrom = (datetime.date.today() - datetime.timedelta(days=int(days))).isoformat()
    dto = datetime.date.today().isoformat()
    exps = db.list_other_expenses(company_id, dfrom, dto)
    st.dataframe(exps, use_container_width=True, hide_index=True)
    if len(exps):
        df_download_button(exps, "gastos.csv", "Descargar gastos (CSV)")

# ---------------------------
# Reportes
# ---------------------------
elif page == "📑 Reportes":
    st.subheader("Reporte mensual por Centro de Costo")
    today = datetime.date.today()
    c1, c2 = st.columns([1,1])
    with c1:
        year = st.number_input("Año", value=int(today.year), step=1)
    with c2:
        month = st.selectbox("Mes", options=list(range(1,13)), index=int(today.month)-1)
    rep = db.monthly_report_cc(company_id, int(year), int(month))
    if len(rep):
        st.dataframe(rep, use_container_width=True, hide_index=True)
        df_download_button(rep, f"reporte_cc_{year}-{int(month):02d}.csv", "Descargar reporte CC (CSV)")
    else:
        st.info("Sin datos para ese mes.")

    st.markdown("---")
    st.subheader("Exportar a Excel (compras/movimientos/gastos)")
    c1, c2 = st.columns([1,1])
    with c1:
        date_from = st.date_input("Desde", value=(today - datetime.timedelta(days=90)), key="exp_x_from")
    with c2:
        date_to = st.date_input("Hasta", value=today, key="exp_x_to")

    if st.button("Generar Excel", type="primary"):
        out_path = os.path.join(db.data_dir(), f"MiniERP_export_{company_id}_{today.isoformat()}.xlsx")
        path = db.export_excel(company_id, date_from.isoformat(), date_to.isoformat(), out_path)
        with open(path, "rb") as f:
            st.download_button("Descargar Excel", data=f.read(), file_name=os.path.basename(path),
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# ---------------------------
# Admin
# ---------------------------
elif page == "🔐 Admin":
    if str(st.session_state["role"]) != "admin":
        st.error("Solo admin.")
        st.stop()

    st.subheader("Empresas")
    st.dataframe(db.read_df("SELECT id, rut, name, rubro, active FROM companies ORDER BY active DESC, name"),
                 use_container_width=True, hide_index=True)

    with st.expander("Crear empresa", expanded=False):
        rut = st.text_input("RUT", value="")
        name = st.text_input("Razón social", value="")
        rubro = st.selectbox("Rubro", options=["Agrícola","Constructora"])
        if st.button("Crear empresa", type="primary"):
            st.info(db.create_company("admin", rut, name, rubro))
            st.rerun()

    st.markdown("---")
    st.subheader("Usuarios")
    users = db.list_users()
    st.dataframe(users, use_container_width=True, hide_index=True)

    comps = db.read_df("SELECT id, rut, name, rubro FROM companies WHERE active=1 ORDER BY name")
    comp_labels = [db.company_label(r) for _, r in comps.iterrows()]
    comp_ids = comps["id"].tolist()

    with st.expander("Crear usuario", expanded=False):
        u = st.text_input("Username", value="")
        fn = st.text_input("Nombre", value="")
        role = st.selectbox("Rol", options=["compras","bodega","gerente","admin"], index=0)
        pw = st.text_input("Clave (mín 4)", type="password", value="")
        selected = st.multiselect("Empresas asignadas (no-admin)", options=comp_labels)
        chosen_ids = [int(comps.iloc[comp_labels.index(lab)]["id"]) for lab in selected] if selected else []
        if st.button("Crear usuario", type="primary"):
            st.info(db.create_user("admin", u, fn, role, pw, chosen_ids))
            st.rerun()

    with st.expander("Editar usuario", expanded=False):
        if len(users):
            user_pick = st.selectbox("Usuario", options=users["id"].tolist(), format_func=lambda uid: f"#{uid} — {users[users['id']==uid].iloc[0]['username']} ({users[users['id']==uid].iloc[0]['role']})")
            urow = users[users["id"]==user_pick].iloc[0]
            new_role = st.selectbox("Rol nuevo", options=["compras","bodega","gerente","admin"], index=["compras","bodega","gerente","admin"].index(urow["role"]))
            active = st.checkbox("Activo", value=(urow["estado"]=="ACTIVO"))
            new_pw = st.text_input("Nueva clave (opcional)", type="password", value="")
            # current companies
            current = db.read_df("""
              SELECT c.id, c.rut, c.name, c.rubro
              FROM user_companies uc JOIN companies c ON c.id=uc.company_id
              WHERE uc.user_id=? AND c.active=1
            """, (int(user_pick),))
            current_labels = [db.company_label(r) for _, r in current.iterrows()] if len(current) else []
            selected2 = st.multiselect("Empresas", options=comp_labels, default=current_labels)
            chosen_ids2 = [int(comps.iloc[comp_labels.index(lab)]["id"]) for lab in selected2] if selected2 else []
            if st.button("Guardar cambios", type="primary"):
                st.info(db.update_user("admin", int(user_pick), new_role, active, new_pw, chosen_ids2))
                st.rerun()
        else:
            st.info("No hay usuarios.")
