# -*- coding: utf-8 -*-
"""
MiniERP (local) - backend SQLite
Autor: generado por ChatGPT
"""
from __future__ import annotations

import os, sqlite3, datetime, secrets, hashlib, hmac
from contextlib import contextmanager
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd

DEFAULT_VAT = 0.19

def _today() -> str:
    return datetime.date.today().isoformat()

def data_dir() -> str:
    # Prefer env var, else ./data
    d = os.environ.get("MINIERP_DATA_DIR")
    if d:
        os.makedirs(d, exist_ok=True)
        return d
    d = os.path.join(os.path.dirname(__file__), "data")
    os.makedirs(d, exist_ok=True)
    return d

def db_path() -> str:
    return os.path.join(data_dir(), "mini_erp.db")

@contextmanager
def conn():
    c = sqlite3.connect(db_path(), check_same_thread=False)
    c.execute("PRAGMA foreign_keys=ON;")
    try:
        yield c
        c.commit()
    finally:
        c.close()

def exec_sql(q: str, params: Tuple[Any, ...] = ()) -> int:
    with conn() as c:
        cur = c.cursor()
        cur.execute(q, params)
        return cur.lastrowid

def read_df(q: str, params: Tuple[Any, ...] = ()) -> pd.DataFrame:
    with conn() as c:
        return pd.read_sql_query(q, c, params=params)

# ---------------------------
# Password hashing (PBKDF2)
# ---------------------------
def _pbkdf2_hash(password: str, salt: bytes, iterations: int = 120_000) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    h = _pbkdf2_hash(password, salt)
    return f"pbkdf2_sha256$120000${salt.hex()}${h.hex()}"

def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        salt = bytes.fromhex(salt_hex)
        iters_i = int(iters)
        expected = bytes.fromhex(hash_hex)
        got = _pbkdf2_hash(password, salt, iters_i)
        return hmac.compare_digest(got, expected)
    except Exception:
        return False

# ---------------------------
# Init DB
# ---------------------------
SCHEMA = """
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS companies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rut TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  rubro TEXT NOT NULL CHECK (rubro IN ('Agrícola','Constructora')),
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT NOT NULL CHECK (role IN ('admin','compras','bodega','gerente')),
  password_hash TEXT NOT NULL,
  active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS user_companies(
  user_id INTEGER NOT NULL,
  company_id INTEGER NOT NULL,
  PRIMARY KEY(user_id, company_id),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS families(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  UNIQUE(company_id, name),
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  sku TEXT,
  name TEXT NOT NULL,
  family_id INTEGER,
  unit TEXT DEFAULT 'UN',
  min_stock REAL DEFAULT 0,
  active INTEGER DEFAULT 1,
  UNIQUE(company_id, sku),
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY(family_id) REFERENCES families(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS suppliers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  rut TEXT,
  phone TEXT,
  email TEXT,
  active INTEGER DEFAULT 1,
  UNIQUE(company_id, name),
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Compras (proveedor se asocia a la compra/ingreso, no al producto)
CREATE TABLE IF NOT EXISTS purchases(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  due_date TEXT,
  supplier_id INTEGER,
  doc_no TEXT,
  cost_center TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS purchase_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  qty REAL NOT NULL,
  unit_cost_net REAL NOT NULL,
  vat_rate REAL NOT NULL DEFAULT 0.19,
  FOREIGN KEY(purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT
);

-- Movimientos de stock con fecha
CREATE TABLE IF NOT EXISTS stock_moves(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  move_type TEXT NOT NULL CHECK (move_type IN ('IN','OUT','ADJ')),
  product_id INTEGER NOT NULL,
  qty REAL NOT NULL,
  ref TEXT,
  cost_center TEXT,
  supplier_id INTEGER,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT,
  FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

-- Gastos no-factura
CREATE TABLE IF NOT EXISTS other_expenses(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  amount_net REAL NOT NULL,
  vat_rate REAL NOT NULL DEFAULT 0.0,
  method TEXT,
  reference TEXT,
  cost_center TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
"""

def init_db() -> None:
    with conn() as c:
        c.executescript(SCHEMA)

def ensure_seed() -> None:
    init_db()
    # company demo
    d = read_df("SELECT id FROM companies WHERE active=1 ORDER BY id LIMIT 1")
    if len(d) == 0:
        exec_sql("INSERT INTO companies(rut,name,rubro,active) VALUES(?,?,?,1)",
                 ("76.123.456-7", "Empresa Demo", "Agrícola"))
    # admin
    u = read_df("SELECT id FROM users WHERE username='admin' AND active=1 LIMIT 1")
    if len(u) == 0:
        admin_id = exec_sql(
            "INSERT INTO users(username,full_name,role,password_hash,active) VALUES(?,?,?,?,1)",
            ("admin", "Administrador", "admin", hash_password("admin123"))
        )
    else:
        admin_id = int(u.iloc[0]["id"])
    # assign admin to all active companies
    for _, r in read_df("SELECT id FROM companies WHERE active=1").iterrows():
        exec_sql("INSERT OR IGNORE INTO user_companies(user_id,company_id) VALUES(?,?)",
                 (admin_id, int(r["id"])))

# ---------------------------
# Auth / permissions
# ---------------------------
def login(username: str, password: str) -> Tuple[bool, str, Optional[int], Optional[str]]:
    ensure_seed()
    username = (username or "").strip()
    u = read_df("SELECT id, role, password_hash, active FROM users WHERE username=?", (username,))
    if len(u) == 0 or int(u.iloc[0]["active"]) != 1:
        return False, "Usuario no existe o está inactivo.", None, None
    if not verify_password(password or "", u.iloc[0]["password_hash"]):
        return False, "Contraseña incorrecta.", None, None
    return True, "OK", int(u.iloc[0]["id"]), str(u.iloc[0]["role"])

def user_companies(user_id: int, role: str) -> pd.DataFrame:
    if role == "admin":
        return read_df("SELECT id, rut, name, rubro FROM companies WHERE active=1 ORDER BY name")
    return read_df("""
      SELECT c.id, c.rut, c.name, c.rubro
      FROM user_companies uc JOIN companies c ON c.id=uc.company_id
      WHERE uc.user_id=? AND c.active=1
      ORDER BY c.name
    """, (user_id,))

def company_label(row) -> str:
    return f"{row['rut']} - {row['name']} ({row['rubro']})"

def get_company(company_id: int) -> Dict[str, Any]:
    d = read_df("SELECT id, rut, name, rubro FROM companies WHERE id=? AND active=1", (company_id,))
    if len(d) == 0:
        raise ValueError("Empresa no existe o está inactiva.")
    return d.iloc[0].to_dict()

def require(role: str, allowed: Iterable[str]) -> bool:
    return role in set(allowed)

# ---------------------------
# Admin (companies/users)
# ---------------------------
def create_company(current_role: str, rut: str, name: str, rubro: str) -> str:
    if current_role != "admin":
        return "Solo admin puede crear empresas."
    rut = (rut or "").strip()
    name = (name or "").strip()
    if not rut or not name or rubro not in ("Agrícola","Constructora"):
        return "Completa RUT, razón social y rubro."
    try:
        cid = exec_sql("INSERT INTO companies(rut,name,rubro,active) VALUES(?,?,?,1)", (rut, name, rubro))
        # assign admin
        admin = read_df("SELECT id FROM users WHERE username='admin' LIMIT 1")
        if len(admin):
            exec_sql("INSERT OR IGNORE INTO user_companies(user_id,company_id) VALUES(?,?)",
                     (int(admin.iloc[0]["id"]), cid))
        return f"Empresa creada: #{cid}"
    except sqlite3.IntegrityError:
        return "Ya existe una empresa con ese RUT."

def list_users() -> pd.DataFrame:
    return read_df("""
      SELECT u.id, u.username, COALESCE(u.full_name,'') full_name, u.role,
             CASE WHEN u.active=1 THEN 'ACTIVO' ELSE 'INACTIVO' END estado,
             COALESCE(GROUP_CONCAT(c.name, ' | '), '') empresas
      FROM users u
      LEFT JOIN user_companies uc ON uc.user_id=u.id
      LEFT JOIN companies c ON c.id=uc.company_id AND c.active=1
      GROUP BY u.id
      ORDER BY u.username
    """)

def create_user(current_role: str, username: str, full_name: str, role: str, password: str, company_ids: List[int]) -> str:
    if current_role != "admin":
        return "Solo admin puede crear usuarios."
    username = (username or "").strip()
    full_name = (full_name or "").strip()
    password = password or ""
    if not username or len(password) < 4:
        return "Usuario y clave (mín 4) son obligatorios."
    if role not in ("admin","compras","bodega","gerente"):
        return "Rol inválido."
    if role != "admin" and not company_ids:
        return "Un usuario NO-admin debe tener al menos 1 empresa."
    try:
        uid = exec_sql(
            "INSERT INTO users(username,full_name,role,password_hash,active) VALUES(?,?,?,?,1)",
            (username, full_name or None, role, hash_password(password))
        )
        # asignaciones
        exec_sql("DELETE FROM user_companies WHERE user_id=?", (uid,))
        for cid in company_ids:
            exec_sql("INSERT OR IGNORE INTO user_companies(user_id,company_id) VALUES(?,?)", (uid, int(cid)))
        return f"Usuario creado: #{uid}"
    except sqlite3.IntegrityError:
        return "Ya existe ese username."

def update_user(current_role: str, user_id: int, role: str, active: bool, new_password: str, company_ids: List[int]) -> str:
    if current_role != "admin":
        return "Solo admin."
    if role not in ("admin","compras","bodega","gerente"):
        return "Rol inválido."
    exec_sql("UPDATE users SET role=?, active=? WHERE id=?", (role, 1 if active else 0, int(user_id)))
    if new_password and len(new_password) >= 4:
        exec_sql("UPDATE users SET password_hash=? WHERE id=?", (hash_password(new_password), int(user_id)))
    # enforce companies for non-admin
    role_now = read_df("SELECT role FROM users WHERE id=?", (int(user_id),))
    if len(role_now) and role_now.iloc[0]["role"] != "admin" and not company_ids:
        return "Un usuario NO-admin debe tener al menos 1 empresa asignada."
    exec_sql("DELETE FROM user_companies WHERE user_id=?", (int(user_id),))
    for cid in company_ids:
        exec_sql("INSERT OR IGNORE INTO user_companies(user_id,company_id) VALUES(?,?)", (int(user_id), int(cid)))
    return "Usuario actualizado."

# ---------------------------
# Masters
# ---------------------------
def list_families(company_id: int) -> pd.DataFrame:
    return read_df("SELECT id, name FROM families WHERE company_id=? ORDER BY name", (company_id,))

def upsert_family(company_id: int, name: str, family_id: Optional[int] = None) -> str:
    name = (name or "").strip()
    if not name:
        return "Nombre de familia es obligatorio."
    try:
        if family_id:
            exec_sql("UPDATE families SET name=? WHERE id=? AND company_id=?", (name, int(family_id), company_id))
            return "Familia actualizada."
        exec_sql("INSERT INTO families(company_id,name) VALUES(?,?)", (company_id, name))
        return "Familia creada."
    except sqlite3.IntegrityError:
        return "Ya existe una familia con ese nombre."

def delete_family(company_id: int, family_id: int) -> str:
    # Si hay productos referenciando, SQLite pondrá family_id NULL por ON DELETE SET NULL
    exec_sql("DELETE FROM families WHERE id=? AND company_id=?", (int(family_id), company_id))
    return "Familia eliminada."

def list_products(company_id: int, active_only: bool=True) -> pd.DataFrame:
    where = "AND p.active=1" if active_only else ""
    return read_df(f"""
      SELECT p.id, COALESCE(p.sku,'') sku, p.name, COALESCE(f.name,'') family, p.unit, p.min_stock, p.active
      FROM products p
      LEFT JOIN families f ON f.id=p.family_id
      WHERE p.company_id=? {where}
      ORDER BY p.name
    """, (company_id,))

def upsert_product(company_id: int, sku: str, name: str, family_id: Optional[int], unit: str, min_stock: float, active: bool, product_id: Optional[int]=None) -> str:
    sku = (sku or "").strip() or None
    name = (name or "").strip()
    unit = (unit or "UN").strip() or "UN"
    if not name:
        return "Nombre de producto es obligatorio."
    try:
        if product_id:
            exec_sql("""
              UPDATE products
              SET sku=?, name=?, family_id=?, unit=?, min_stock=?, active=?
              WHERE id=? AND company_id=?
            """, (sku, name, int(family_id) if family_id else None, unit, float(min_stock or 0), 1 if active else 0, int(product_id), company_id))
            return "Producto actualizado."
        exec_sql("""
          INSERT INTO products(company_id, sku, name, family_id, unit, min_stock, active)
          VALUES(?,?,?,?,?,?,?)
        """, (company_id, sku, name, int(family_id) if family_id else None, unit, float(min_stock or 0), 1 if active else 0))
        return "Producto creado."
    except sqlite3.IntegrityError:
        return "SKU duplicado en esta empresa (o restricción de datos)."

def delete_product(company_id: int, product_id: int) -> str:
    # Si hay movimientos, RESTRICT impedirá borrar (para no romper histórico)
    try:
        exec_sql("DELETE FROM products WHERE id=? AND company_id=?", (int(product_id), company_id))
        return "Producto eliminado."
    except sqlite3.IntegrityError:
        return "No se puede borrar: el producto tiene movimientos asociados. Desactívalo (active=0)."

def list_suppliers(company_id: int) -> pd.DataFrame:
    return read_df("""
      SELECT id, name, COALESCE(rut,'') rut, COALESCE(phone,'') phone, COALESCE(email,'') email, active
      FROM suppliers
      WHERE company_id=?
      ORDER BY active DESC, name
    """, (company_id,))

def upsert_supplier(company_id: int, name: str, rut: str, phone: str, email: str, active: bool, supplier_id: Optional[int]=None) -> str:
    name = (name or "").strip()
    if not name:
        return "Nombre proveedor es obligatorio."
    rut = (rut or "").strip() or None
    phone = (phone or "").strip() or None
    email = (email or "").strip() or None
    try:
        if supplier_id:
            exec_sql("""
              UPDATE suppliers SET name=?, rut=?, phone=?, email=?, active=?
              WHERE id=? AND company_id=?
            """, (name, rut, phone, email, 1 if active else 0, int(supplier_id), company_id))
            return "Proveedor actualizado."
        exec_sql("""
          INSERT INTO suppliers(company_id,name,rut,phone,email,active) VALUES(?,?,?,?,?,?)
        """, (company_id, name, rut, phone, email, 1 if active else 0))
        return "Proveedor creado."
    except sqlite3.IntegrityError:
        return "Ya existe un proveedor con ese nombre."

def delete_supplier(company_id: int, supplier_id: int) -> str:
    exec_sql("DELETE FROM suppliers WHERE id=? AND company_id=?", (int(supplier_id), company_id))
    return "Proveedor eliminado."

# ---------------------------
# Stock / compras / gastos
# ---------------------------
def stock_now(company_id: int) -> pd.DataFrame:
    return read_df("""
      SELECT p.id, COALESCE(p.sku,'') sku, p.name, p.unit,
             ROUND(COALESCE(SUM(CASE
               WHEN m.move_type='IN' THEN m.qty
               WHEN m.move_type='OUT' THEN -m.qty
               WHEN m.move_type='ADJ' THEN m.qty
               ELSE 0 END),0),3) AS stock
      FROM products p
      LEFT JOIN stock_moves m ON m.product_id=p.id AND m.company_id=?
      WHERE p.company_id=? AND p.active=1
      GROUP BY p.id
      ORDER BY p.name
    """, (company_id, company_id))

def list_stock_moves(company_id: int, date_from: str, date_to: str) -> pd.DataFrame:
    return read_df("""
      SELECT m.id, m.date, m.move_type, p.name product, m.qty,
             COALESCE(s.name,'') supplier,
             COALESCE(m.cost_center,'') cost_center, COALESCE(m.ref,'') ref,
             COALESCE(m.notes,'') notes
      FROM stock_moves m
      JOIN products p ON p.id=m.product_id
      LEFT JOIN suppliers s ON s.id=m.supplier_id
      WHERE m.company_id=? AND date(m.date) BETWEEN date(?) AND date(?)
      ORDER BY date(m.date) DESC, m.id DESC
    """, (company_id, date_from, date_to))

def _purchase_totals(purchase_id: int) -> Tuple[float,float,float]:
    d = read_df("""
      SELECT
        COALESCE(SUM(qty*unit_cost_net),0) net,
        COALESCE(SUM(qty*unit_cost_net*vat_rate),0) vat,
        COALESCE(SUM(qty*unit_cost_net*(1+vat_rate)),0) gross
      FROM purchase_items WHERE purchase_id=?
    """, (purchase_id,))
    net = float(d.iloc[0]["net"])
    vat = float(d.iloc[0]["vat"])
    gross = float(d.iloc[0]["gross"])
    return round(net,2), round(vat,2), round(gross,2)

def list_purchases(company_id: int, date_from: str, date_to: str) -> pd.DataFrame:
    base = read_df("""
      SELECT p.id, p.date, COALESCE(p.due_date,'') due_date,
             COALESCE(s.name,'(Sin proveedor)') supplier,
             COALESCE(p.doc_no,'') doc_no,
             COALESCE(p.cost_center,'') cost_center,
             COALESCE(p.notes,'') notes
      FROM purchases p
      LEFT JOIN suppliers s ON s.id=p.supplier_id
      WHERE p.company_id=? AND date(p.date) BETWEEN date(?) AND date(?)
      ORDER BY date(p.date) DESC, p.id DESC
    """, (company_id, date_from, date_to))
    rows = []
    for _, r in base.iterrows():
        net, vat, gross = _purchase_totals(int(r["id"]))
        rows.append({**r.to_dict(), "net": net, "vat": vat, "gross": gross})
    return pd.DataFrame(rows).reset_index(drop=True)

def create_purchase(
    company_id: int,
    date: str,
    due_date: str,
    supplier_id: Optional[int],
    doc_no: str,
    cost_center: str,
    notes: str,
    lines: List[Dict[str, Any]],
) -> str:
    if not lines:
        return "Debes agregar al menos 1 línea."
    date = date or _today()
    pid = exec_sql("""
      INSERT INTO purchases(company_id,date,due_date,supplier_id,doc_no,cost_center,notes)
      VALUES(?,?,?,?,?,?,?)
    """, (
        company_id,
        date,
        (due_date or "").strip() or None,
        int(supplier_id) if supplier_id else None,
        (doc_no or "").strip() or None,
        (cost_center or "").strip() or None,
        (notes or "").strip() or None,
    ))
    for ln in lines:
        product_id = int(ln["product_id"])
        qty = float(ln["qty"])
        unit_net = float(ln["unit_cost_net"])
        vat_rate = float(ln.get("vat_rate", DEFAULT_VAT))
        exec_sql("""
          INSERT INTO purchase_items(purchase_id,product_id,qty,unit_cost_net,vat_rate)
          VALUES(?,?,?,?,?)
        """, (pid, product_id, qty, unit_net, vat_rate))
        exec_sql("""
          INSERT INTO stock_moves(company_id,date,move_type,product_id,qty,ref,cost_center,supplier_id,notes)
          VALUES(?,?,?,?,?,?,?,?,?)
        """, (company_id, date, "IN", product_id, qty, f"purchase:{pid}",
              (cost_center or "").strip() or None,
              int(supplier_id) if supplier_id else None,
              (notes or "").strip() or None))
    net, vat, gross = _purchase_totals(pid)
    return f"Compra guardada #{pid} — Neto {net:,.0f} | IVA {vat:,.0f} | Total {gross:,.0f}".replace(",", ".")

def create_stock_move(
    company_id: int,
    date: str,
    move_type: str,
    product_id: int,
    qty: float,
    supplier_id: Optional[int],
    cost_center: str,
    ref: str,
    notes: str,
) -> str:
    """
    IN: qty > 0 (se suma)
    OUT: qty > 0 (se resta)
    ADJ: qty puede ser + o - (se suma tal cual)
    """
    date = date or _today()
    move_type = (move_type or "").strip().upper()
    if move_type not in ("IN","OUT","ADJ"):
        return "Tipo movimiento inválido."
    try:
        qty = float(qty)
    except Exception:
        return "Cantidad inválida."
    if move_type in ("IN","OUT") and qty <= 0:
        return "Cantidad debe ser > 0."
    if move_type == "ADJ" and qty == 0:
        return "Cantidad no puede ser 0."

    qty_store = float(abs(qty)) if move_type in ("IN","OUT") else float(qty)

    exec_sql("""
      INSERT INTO stock_moves(company_id,date,move_type,product_id,qty,ref,cost_center,supplier_id,notes)
      VALUES(?,?,?,?,?,?,?,?,?)
    """, (
        company_id, date, move_type, int(product_id), qty_store,
        (ref or "").strip() or None,
        (cost_center or "").strip() or None,
        int(supplier_id) if supplier_id else None,
        (notes or "").strip() or None,
    ))
    return "Movimiento guardado."

def create_out_move(company_id: int, date: str, product_id: int, qty: float, cost_center: str, ref: str, notes: str) -> str:
    # OUT se guarda como move_type='OUT' y qty positivo
    return create_stock_move(company_id, date, "OUT", product_id, qty, None, cost_center, ref, notes)

def add_other_expense(
    company_id: int,
    date: str,
    category: str,
    description: str,
    amount_net: float,
    vat_rate: float,
    method: str,
    reference: str,
    cost_center: str,
    notes: str,
) -> str:
    date = date or _today()
    category = (category or "").strip()
    if not category:
        return "Categoría es obligatoria."
    amount_net = float(amount_net or 0)
    if amount_net <= 0:
        return "Monto neto debe ser > 0."
    vat_rate = float(vat_rate or 0)
    exec_sql("""
      INSERT INTO other_expenses(company_id,date,category,description,amount_net,vat_rate,method,reference,cost_center,notes)
      VALUES(?,?,?,?,?,?,?,?,?,?)
    """, (
        company_id, date, category,
        (description or "").strip() or None,
        amount_net, vat_rate,
        (method or "").strip() or None,
        (reference or "").strip() or None,
        (cost_center or "").strip() or None,
        (notes or "").strip() or None,
    ))
    gross = round(amount_net*(1+vat_rate),2)
    return f"Gasto guardado — Total {gross:,.0f}".replace(",", ".")

def list_other_expenses(company_id: int, date_from: str, date_to: str) -> pd.DataFrame:
    return read_df("""
      SELECT id, date, category, COALESCE(description,'') description,
             amount_net, vat_rate,
             ROUND(amount_net*(1+vat_rate),2) total,
             COALESCE(method,'') method, COALESCE(reference,'') reference,
             COALESCE(cost_center,'') cost_center, COALESCE(notes,'') notes
      FROM other_expenses
      WHERE company_id=? AND date(date) BETWEEN date(?) AND date(?)
      ORDER BY date(date) DESC, id DESC
    """, (company_id, date_from, date_to))

def monthly_report_cc(company_id: int, year: int, month: int) -> pd.DataFrame:
    ym_start = datetime.date(year, month, 1)
    ym_end = (datetime.date(year+1,1,1) if month==12 else datetime.date(year, month+1, 1))
    start = ym_start.isoformat()
    end = (ym_end - datetime.timedelta(days=1)).isoformat()
    compras = list_purchases(company_id, start, end)
    gastos = list_other_expenses(company_id, start, end)

    # compras por CC
    if len(compras):
        c = compras.copy()
        c["cc"] = c["cost_center"].fillna("").replace("", "(Sin CC)")
        g_comp = c.groupby("cc", as_index=False).agg(net=("net","sum"), vat=("vat","sum"), gross=("gross","sum"))
        g_comp["tipo"] = "Compras"
    else:
        g_comp = pd.DataFrame(columns=["cc","net","vat","gross","tipo"])

    if len(gastos):
        g = gastos.copy()
        g["cc"] = g["cost_center"].fillna("").replace("", "(Sin CC)")
        g["net"] = g["amount_net"].astype(float)
        g["vat"] = (g["amount_net"].astype(float) * g["vat_rate"].astype(float)).round(2)
        g["gross"] = g["total"].astype(float)
        g_exp = g.groupby("cc", as_index=False).agg(net=("net","sum"), vat=("vat","sum"), gross=("gross","sum"))
        g_exp["tipo"] = "Gastos"
    else:
        g_exp = pd.DataFrame(columns=["cc","net","vat","gross","tipo"])

    out = pd.concat([g_comp, g_exp], ignore_index=True)
    if len(out)==0:
        return out
    out = out.sort_values(["tipo","cc"]).reset_index(drop=True)
    for col in ("net","vat","gross"):
        out[col] = out[col].round(2)
    return out

def export_excel(company_id: int, date_from: str, date_to: str, out_path: str) -> str:
    company = read_df("SELECT id, rut, name, rubro FROM companies WHERE id=?", (company_id,))
    products = list_products(company_id, active_only=False)
    families = list_families(company_id)
    suppliers = list_suppliers(company_id)
    purchases = list_purchases(company_id, date_from, date_to)
    moves = list_stock_moves(company_id, date_from, date_to)
    expenses = list_other_expenses(company_id, date_from, date_to)
    stock = stock_now(company_id)

    with pd.ExcelWriter(out_path, engine="openpyxl") as w:
        company.to_excel(w, "empresa", index=False)
        products.to_excel(w, "productos", index=False)
        families.to_excel(w, "familias", index=False)
        suppliers.to_excel(w, "proveedores", index=False)
        purchases.to_excel(w, "compras", index=False)
        moves.to_excel(w, "movimientos_stock", index=False)
        expenses.to_excel(w, "gastos", index=False)
        stock.to_excel(w, "stock_actual", index=False)
    return out_path
