# MiniERP (Streamlit) — Despliegue en la web SIN instalar Python

Este proyecto es una app web (Streamlit) para inventario + compras/ventas + CxP/CxC + gastos + contabilidad básica.

- **No necesitas instalar Python** si la despliegas en un hosting que ejecute Python por ti.
- Los datos se guardan en una **BD SQLite** (un archivo). Para que NO se borre, el hosting debe tener **disco persistente** o una **BD externa**.

---

## Opción A (recomendada): Render (Docker) — 100% web

Esta opción usa el `Dockerfile` y `render.yaml` incluidos.

### 1) Subir el código a GitHub
1. Crea una cuenta en GitHub.
2. Crea un repositorio nuevo (por ejemplo `minierp`).
3. Sube **todo el contenido** de la carpeta `MiniERP_Streamlit/` (los archivos: `app.py`, `minierp_db.py`, `Dockerfile`, `render.yaml`, etc.).

> Tip: en GitHub puedes usar **Add file → Upload files** y arrastrar los archivos.

### 2) Deploy en Render (Blueprint)
1. Crea una cuenta en Render.
2. En Render: **New → Blueprint**.
3. Conecta tu repositorio de GitHub.
4. Render detectará `render.yaml` y levantará el servicio.

### 3) Activar persistencia (clave)
Para que NO se borre la base de datos:
1. En Render, agrega un **Persistent Disk** al servicio.
2. Monta el disco, por ejemplo en: `/var/data`
3. Agrega variable de entorno:
   - `MINIERP_DATA_DIR=/var/data`

Con esto, la BD quedará en el disco persistente y seguirá ahí aunque reinicies.

### 4) Entrar
Render te dará una URL pública, por ejemplo `https://xxxx.onrender.com`.

**Login inicial:** `admin` / `admin123`

---

## Opción B: Streamlit Community Cloud — MUY fácil, pero ojo con persistencia

1. Sube el repo a GitHub (igual que arriba).
2. En Streamlit Community Cloud: **New app** y elige tu repo.
3. Selecciona el archivo **`app.py`**.

⚠️ Importante: dependiendo del plan/entorno, el almacenamiento puede no ser un “disco persistente garantizado”.
Si necesitas que los datos sí o sí queden guardados, usa Render con disco, o cambia a BD externa.

---

## Opción C: Hugging Face Spaces — usando Docker

Hugging Face Spaces soporta correr apps con **Docker** (y este proyecto ya trae `Dockerfile`).
1. Crea un Space nuevo.
2. Elige **SDK: Docker**.
3. Sube el repositorio.

⚠️ Igual que arriba: revisa persistencia/almacenamiento del Space.

---

## Si quieres 0 mantención (alternativa SaaS)
Si tu prioridad es que funcione ya (sin hosting, sin Docker, sin nada):
- **Odoo Online** (Inventario + Compras + Ventas + Contabilidad, multi-empresa y centros de costo/analítica).
- **ERPNext (Frappe Cloud)** (ERP completo en la web).

---

## Soporte rápido (si falla)
- En Render, revisa **Logs** del servicio.
- Confirma que exista la variable `MINIERP_DATA_DIR` y el disco esté montado.
- Si cambiaste puertos, deja que el hosting use el puerto que te entregue por variable `PORT` (Dockerfile ya lo contempla).

